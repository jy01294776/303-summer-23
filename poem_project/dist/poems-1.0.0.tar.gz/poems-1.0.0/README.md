# Poems

The program that stores favorite and least favorite poems.

## Installation

No installation required. Just run the `poems.py` script and import 'mypoems'

## Usage

this is to access your favorite and least favorite poems.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
